<?php





?>


<html>
<head>
<meta charset="UTF-8">
<title>Data Form</title>
</head>

<body>

	<main class="content">
		<section>
			<h2><?php echo $response ?></h2>
		 </section>
	</main>

</body>
</html>
