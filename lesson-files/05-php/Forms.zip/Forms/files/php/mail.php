<?php

 

?>





<html>
<head>
<meta charset="UTF-8">
<title>Email Form</title>
	<link rel="stylesheet" type="text/css" href="../css/normalise.css">
	<link rel="stylesheet" type="text/css" href="../css/base.css">

</head>

<body>


		<main class="content">
		<section>
			<h2><?php echo $response ?></h2>

		 </section>
		</main>

</body>
</html>
