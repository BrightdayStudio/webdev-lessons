$(document).ready(function() {
    var $name = "John Doe";
    console.log( "Welcome " + $name );
    $(".text").append("Welcome " + $name );
});
