$( document ).ready( function() {

$('.readmore span').hide();

$('.readmore a').click( function() {
  $('.readmore span').show();
  $('.readmore a').hide();
});


});
