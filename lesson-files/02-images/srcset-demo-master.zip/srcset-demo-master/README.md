# srcset Demo

## A Demo using the srcset img attribute 

```
<img class="srcset-demo-img" alt=""
	src="images/2000x1000.png"
	srcset="images/500x250.png 500w,images/1000x500.png 1000w,images/2000x1000.png 2000w"
>
```

## Demo Available At

[srcset.salcode.com](http://srcset.salcode.com/)
