<html>
 <head>
  <title>PHP Test</title>
  <link rel="stylesheet" type="text/css" href="css/normalise.css" />
  <link rel="stylesheet" type="text/css" media="screen" href="css/base.css" />
 </head>
 <body>
 <?php echo '<h1>Hello World</h1>'; ?>
 </body>
</html>
