# webdev-lessons
Web Development lessons

This is for a course on Web Development Basics.

A basic setup ready for HTML to be added. Basic style is already included.
